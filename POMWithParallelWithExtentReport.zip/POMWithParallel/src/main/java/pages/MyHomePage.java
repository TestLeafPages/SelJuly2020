package pages;

import base.BaseClass;

public class MyHomePage extends BaseClass{

}
