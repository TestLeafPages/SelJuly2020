package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class HomePage extends BaseClass {
	
	
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(how=How.CLASS_NAME, using="decorativeSubmit")
	WebElement eleLogoutButton;
	
	public LoginPage clickLogoutButton() {
		eleLogoutButton.click();
		
		//driver.findElementByClassName("decorativeSubmit").click();
		
		return new LoginPage(driver);

	}
	
	public HomePage verifyHomePage() {
		String title = driver.getTitle();
		
		if (title.contains("Leaftaps")) {
			System.out.println("we are in right page");
		}
		else {
			System.out.println("we are not in right page");
		}

		return this;
	}

}
