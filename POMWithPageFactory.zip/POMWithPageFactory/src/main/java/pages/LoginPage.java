package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class LoginPage extends BaseClass {
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
	
	//@FindBy(xpath="//input[@id='username']" )
	//And Condition
	/*
	 * @FindBys({
	 * 
	 * @FindBy(how=How.ID,using="username"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@class='inputLogin']") })
	 */
	/*
	 * @FindAll({
	 * 
	 * @FindBy(how=How.ID,using="username123"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@class='inputLogin']") })
	 */
	@CacheLookup @FindBy(xpath="//input[@id='username']" ) WebElement eleUserName;
	@CacheLookup @FindBy(how=How.ID, using="password" ) 	WebElement elePassword;
	@FindBy(how=How.CLASS_NAME, using="decorativeSubmit" ) WebElement eleLoginButton;
	

	public LoginPage enterUserName() {
		
		//WebElement webElement = eleUserName.get(0);
		
		eleUserName.sendKeys("Demosalesmanager");
		
		//driver.findElementById("username").sendKeys("Demosalesmanager");
		
		return this;

	}

	
	
	public LoginPage enterPassword() throws InterruptedException {
		elePassword.sendKeys("crmsfa");
		
	//	driver.findElementById("password").sendKeys("crmsfa");
		
		return this;
	}
	
	

	public HomePage clickLoginButton() {
		eleLoginButton.click();
		//driver.findElementByClassName("decorativeSubmit").click();
		
		return new HomePage(driver);

	}
	
	
	/*
	 * public HomePage clickLogin() { eleLoginButton.click();
	 * 
	 * return new HomePage(driver); }
	 */
	
	public LoginPage verifyErrorMessage() {
		System.out.println("error message should be displayed");
		
		return this;

	}

}
