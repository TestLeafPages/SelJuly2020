package week7.day2;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnExceptionHandling {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.get("http://leaftaps.com/opentaps/control/main");

		try {

			driver.findElementById("username123").sendKeys("Demosalesmanager");

		} finally {
			Runtime.getRuntime().exec("TASKKILL /F /IM chromedriver.exe");
		}

		System.out.println("this is the last line of code");

	}

}
