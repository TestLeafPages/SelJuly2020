package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass {
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	
	

	public LoginPage enterUserName(String data) {
		
		driver.findElementById(prop.getProperty("Login.Username.Id")).sendKeys(data);
		
		return this;

	}

	public LoginPage enterPassword(String data) throws InterruptedException {
		
		driver.findElementById(prop.getProperty("Login.Password.Id")).sendKeys(data);
		
		return this;
	}

	public HomePage clickLoginButton() {
		
		driver.findElementByClassName(prop.getProperty("Login.LoginButton.ClassName")).click();
		
		return new HomePage(driver);

	}
	
	public LoginPage verifyErrorMessage() {
		System.out.println("error message should be displayed");
		
		return this;

	}

}
