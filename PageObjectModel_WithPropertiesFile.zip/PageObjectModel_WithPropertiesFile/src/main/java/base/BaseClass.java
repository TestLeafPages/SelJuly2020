package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import utils.ReadExcel;

public class BaseClass {

	public static ChromeDriver driver;
	public static String title;
	public String fileName;
	public static Properties prop;
	
	@Parameters({"language"})
	@BeforeSuite
	public void propLoad(String lang) throws IOException {
        FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		
		prop = new Properties();
		prop.load(fis);

	}

	@BeforeMethod
	public void preCondition() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@AfterMethod
	public void postCondition() {
		driver.close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
			
		return ReadExcel.excelData(fileName);

	}
	

}
